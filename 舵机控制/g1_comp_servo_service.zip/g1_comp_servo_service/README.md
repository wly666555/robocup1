# g1_comp_servo_service

底层服务进行串口通信，对外提供dds接口