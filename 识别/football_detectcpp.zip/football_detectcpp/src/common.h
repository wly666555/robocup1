const std::vector<std::string> CLASS_NAMES = {
   "Ball", "Goalpost","X","L","T"};

const std::vector<std::vector<unsigned int>> COLORS = {
    {0, 114, 189},   {217, 83, 25},   {237, 177, 32},  {126, 47, 142},  {119, 172, 48} };